<template>
  <div>
    <el-button type="success" icon="el-icon-check" circle @click="sendMailTest()" size="small"></el-button>
  </div>
</template>

<script>

</script>