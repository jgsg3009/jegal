<template>
  <div id="SignUp">
    <div> Sign Up </div>
      name : <input v-model="user.name" placeholder="name"> <br />
      ID : <input v-model="user.id" placeholder="ID"> <br />
      Password : <input v-model="user.password" type="password"  placeholder="password">
    <button v-on:click="signUp" >SignUp</button>
  </div>
</template>

<script>
export default {
  data: function () {
    return {
      user: {
        id: '',
        password: '',
        name: ''
      }
    }
  },
  methods: {
    signUp: function (event) {
      this.$http.post('/api/login/signUp', { //axios 사용
        user: this.user
      })
    }
  }
}
</script>